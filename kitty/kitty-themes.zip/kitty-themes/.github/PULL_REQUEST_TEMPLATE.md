---
name: theme-request
about: Use the following template if you want a new theme to be included in the collection.
title: Add <theme> to the collection.
labels: theme request
assignees: dexpota

---
Please, include **theme** in the collection.
